package com.lohit.bank_project.service.impl;

import com.lohit.bank_project.dto.EmailDetails;
import org.springframework.stereotype.Service;


public interface EmailService {
    void sedEmailAlert(EmailDetails emailDetails);
}
