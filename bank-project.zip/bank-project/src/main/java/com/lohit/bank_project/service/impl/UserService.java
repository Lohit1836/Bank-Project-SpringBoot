package com.lohit.bank_project.service.impl;

import com.lohit.bank_project.dto.BankResponse;
import com.lohit.bank_project.dto.EnquiryRequest;
import com.lohit.bank_project.dto.UserRequest;

public interface UserService {
    BankResponse createAccount(UserRequest userRequest);
    BankResponse balanceEnquiry(EnquiryRequest Request);
    String nameEquiry(EnquiryRequest request);
}
